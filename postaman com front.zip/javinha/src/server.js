const express = require('express');
const path = require('path');
const filaRoutes = require('./routes/filaRoutes');
const app = express();
const PORT = 3000;

// Permite que a API receba dados em JSON
app.use(express.json());

// Registra as rotas da fila
app.use('/fila', filaRoutes);

// Rota principal que entrega a pagina HTML
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'index.html'));
});

// Inicializa o servidor
app.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});

module.exports = app;
