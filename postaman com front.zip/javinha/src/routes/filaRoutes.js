const express = require('express');
const filaController = require('../controllers/filacontroller');
const router = express.Router();

router.post('/', filaController.adicionarPessoa);
router.get('/', filaController.listarFila);
router.post('/chamar', filaController.chamarProximo);
router.get('/atendidos', filaController.listarAtendidos);
router.get('/status', filaController.statusFila);
router.put('/:id', filaController.atualizarPessoa);
router.delete('/:id', filaController.removerPessoa);

module.exports = router;
