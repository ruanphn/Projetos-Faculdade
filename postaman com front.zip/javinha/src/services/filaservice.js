let fila = [];
let atendidos = [];
let idAtual = 1;

function adicionarPessoa(nome, tipo) {
  const pessoa = {
    id: idAtual++,
    nome,
    tipo: tipo || 'normal',
    status: 'aguardando',
    criadoEm: new Date().toLocaleString('pt-BR')
  };
  fila.push(pessoa);
  return pessoa;
}

function listarFila() {
  return fila;
}

function chamarProximo() {
  if (fila.length === 0) {
    return null;
  }
  const indicePrioridade = fila.findIndex(
    pessoa => pessoa.tipo === 'prioridade'
  );
  let pessoaChamada;
  if (indicePrioridade !== -1) {
    pessoaChamada = fila.splice(indicePrioridade, 1)[0];
  } else {
    pessoaChamada = fila.shift();
  }
  pessoaChamada.status = 'atendido';
  pessoaChamada.atendidoEm = new Date().toLocaleString('pt-BR');
  atendidos.push(pessoaChamada);
  return pessoaChamada;
}

function listarAtendidos() {
  return atendidos;
}

function removerPessoa(id) {
  const index = fila.findIndex(
    pessoa => pessoa.id === Number(id)
  );
  if (index === -1) {
    return null;
  }
  const pessoaRemovida = fila.splice(index, 1)[0];
  return pessoaRemovida;
}

function atualizarPessoa(id, dados) {
  const pessoa = fila.find(
    pessoa => pessoa.id === Number(id)
  );
  if (!pessoa) {
    return null;
  }
  pessoa.nome = dados.nome || pessoa.nome;
  pessoa.tipo = dados.tipo || pessoa.tipo;
  return pessoa;
}

function statusFila() {
  return {
    aguardando: fila.length,
    atendidos: atendidos.length,
    totalGeral: fila.length + atendidos.length
  };
}

module.exports = {
  adicionarPessoa,
  listarFila,
  chamarProximo,
  listarAtendidos,
  removerPessoa,
  atualizarPessoa,
  statusFila
};
