const filaService = require('../services/filaservice');

function adicionarPessoa(req, res) {
  const { nome, tipo } = req.body;
  if (!nome) {
    return res.status(400).json({
      mensagem: 'O nome e obrigatorio.'
    });
  }
  if (tipo && tipo !== 'normal' && tipo !== 'prioridade') {
    return res.status(400).json({
      mensagem: 'O tipo deve ser normal ou prioridade.'
    });
  }
  const pessoa = filaService.adicionarPessoa(nome, tipo);
  return res.status(201).json({
    mensagem: 'Pessoa adicionada com sucesso.',
    pessoa
  });
}

function listarFila(req, res) {
  const fila = filaService.listarFila();
  return res.json(fila);
}

function chamarProximo(req, res) {
  const pessoa = filaService.chamarProximo();
  if (!pessoa) {
    return res.status(404).json({
      mensagem: 'Nao ha pessoas na fila.'
    });
  }
  return res.json({
    mensagem: 'Proxima pessoa chamada.',
    pessoa
  });
}

function listarAtendidos(req, res) {
  const atendidos = filaService.listarAtendidos();
  return res.json(atendidos);
}

function removerPessoa(req, res) {
  const { id } = req.params;
  const pessoa = filaService.removerPessoa(id);
  if (!pessoa) {
    return res.status(404).json({
      mensagem: 'Pessoa nao encontrada na fila.'
    });
  }
  return res.json({
    mensagem: 'Pessoa removida com sucesso.',
    pessoa
  });
}

function atualizarPessoa(req, res) {
  const { id } = req.params;
  const pessoa = filaService.atualizarPessoa(id, req.body);
  if (!pessoa) {
    return res.status(404).json({
      mensagem: 'Pessoa nao encontrada na fila.'
    });
  }
  return res.json({
    mensagem: 'Pessoa atualizada com sucesso.',
    pessoa
  });
}

function statusFila(req, res) {
  const status = filaService.statusFila();
  return res.json(status);
}

module.exports = {
  adicionarPessoa,
  listarFila,
  chamarProximo,
  listarAtendidos,
  removerPessoa,
  atualizarPessoa,
  statusFila
};
