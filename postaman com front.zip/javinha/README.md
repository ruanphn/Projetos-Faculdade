# API Fila de Atendimento - Projeto Back-End Completo

## 📋 Descrição

Projeto de aula prático que demonstra uma **arquitetura em camadas profissional** com Node.js, Express e uma interface web interativa. O sistema gerencia uma fila de atendimento com prioridades e fornece uma página HTML que consome a API em tempo real.

### Objetivo
Construir um projeto back-end organizado em Routes, Controllers e Services, com uma página HTML simples que demonstra a comunicação entre Front-End e Back-End.

---

## 🎯 Resultado Final

- ✅ Servidor Express roando na porta 3000
- ✅ Página HTML interativa em `http://localhost:3000`
- ✅ Cadastro de pessoas na fila com tipos normal e prioridade
- ✅ Chamada automática do próximo (prioridade primeiro)
- ✅ Visualização de status em tempo real
- ✅ Edição e remoção de pessoas
- ✅ Timestamps de criação e atendimento

---

## 📁 Estrutura do Projeto

```
javinha/
├── package.json
├── README.md
└── src/
    ├── server.js
    ├── routes/
    │   └── filaRoutes.js
    ├── controllers/
    │   └── filaController.js
    ├── services/
    │   └── filaService.js
    └── views/
        └── index.html
```

---

## 🚀 Como Executar

### Pré-requisitos
- **Node.js** v16+ instalado
- **npm** (vem com Node.js)

### 1. Instalar dependências

```bash
cd c:\Users\Lab 65\Downloads\javinha
npm install
```

### 2. Iniciar em desenvolvimento (com auto-reload)

```bash
npm run dev
```

Mensagem esperada:
```
Servidor rodando em http://localhost:3000
```

### 3. Abrir no navegador

Acesse: **http://localhost:3000**

---

## 🛠️ Arquitetura - Separação de Responsabilidades

### `server.js` - Inicialização
- Configura Express
- Habilita JSON
- Registra rotas
- Serve página HTML
- Inicia servidor na porta 3000

### `filaService.js` - Regras de Negócio
- Gerencia estado da fila (arrays)
- `adicionarPessoa()` - adiciona com ID auto-incrementado
- `chamarProximo()` - prioridade primeiro, depois FIFO
- `removerPessoa()` - remove por ID
- `atualizarPessoa()` - edita nome/tipo
- `statusFila()` - retorna contadores
- Timestamps: `criadoEm` e `atendidoEm`

### `filaController.js` - Validações HTTP
- Valida entrada (nome obrigatório)
- Valida tipo (normal/prioridade)
- Retorna status HTTP corretos (201, 404, 400)
- Formatação de respostas

### `filaRoutes.js` - Endpoints da API
```
POST   /fila           → Adiciona
GET    /fila           → Lista aguardando
POST   /fila/chamar    → Chama próximo
GET    /fila/atendidos → Lista atendidos
GET    /fila/status    → Retorna contadores
PUT    /fila/:id       → Atualiza
DELETE /fila/:id       → Remove
```

### `index.html` - Frontend
- CSS responsivo com grid
- Fetch assincronista
- Atualiza tabela em tempo real
- Edição via prompt
- Confirmação de remoção
- Cards de estatísticas

---

## 📡 Testando a API

### Com `curl` no terminal

**Adicionar pessoa:**
```bash
curl -X POST http://localhost:3000/fila \
  -H "Content-Type: application/json" \
  -d '{"nome":"Maria","tipo":"normal"}'
```

**Listar fila:**
```bash
curl http://localhost:3000/fila
```

**Chamar próximo:**
```bash
curl -X POST http://localhost:3000/fila/chamar
```

**Status:**
```bash
curl http://localhost:3000/fila/status
```

**Remover (ID 1):**
```bash
curl -X DELETE http://localhost:3000/fila/1
```

### Resposta esperada (POST /fila)
```json
{
  "mensagem": "Pessoa adicionada com sucesso.",
  "pessoa": {
    "id": 1,
    "nome": "Maria",
    "tipo": "normal",
    "status": "aguardando",
    "criadoEm": "08/06/2026, 14:30:45"
  }
}
```

---

## 🧪 Teste Manual - Cenário Completo

1. Abra **http://localhost:3000**
2. Digite **"João"** no campo de nome
3. Selecione tipo **"prioridade"**
4. Clique em **"Adicionar"**
5. Digite **"Maria"** e deixe tipo **"normal"**
6. Clique em **"Adicionar"**
7. Clique em **"Chamar Próximo"** → João deve ser chamado (prioridade)
8. Clique novamente → Maria deve ser chamada
9. Veja o status: 0 aguardando, 2 atendidos
10. Edite ou remova pessoas na tabela

---

## 📚 Conceitos Trabalhados

- ✅ **API REST** - Requisições HTTP
- ✅ **Node.js & Express** - Framework web
- ✅ **Arquitetura em Camadas** - Separação: Routes → Controllers → Services
- ✅ **JSON** - Troca de dados
- ✅ **Status HTTP** - 201, 404, 400, 200
- ✅ **Fila com Prioridade** - Algoritmo de ordenação
- ✅ **Fetch API** - Consumo assincronista
- ✅ **DOM** - Manipulação dinâmica
- ✅ **Responsividade** - CSS Grid
- ✅ **Timestamps** - Registro de datas

---

## 🎓 Desafios para Evolução

1. **Persistência**: Salvar fila em arquivo JSON ou SQLite
2. **Busca**: Adicionar campo para filtrar por nome
3. **Validação**: Impedir nomes duplicados
4. **Limite**: Máximo de pessoas na fila
5. **Estilo**: Adicionar Bootstrap ou Tailwind
6. **Separação**: CSS e JS em arquivos externos
7. **Atendidos**: Página separada com histórico
8. **Notificações**: Toast ou modal ao chamar próximo

---

## ❌ Erros Comuns

| Erro | Solução |
|------|---------|
| `Cannot find module express` | Execute `npm install express` |
| `Cannot find module nodemon` | Execute `npm install nodemon --save-dev` |
| Página não abre | Verifique se servidor está rodando com `npm run dev` |
| Erro 404 no HTML | Confirme arquivo em `src/views/index.html` |
| CORS error | Não aplica (servidor e frontend mesmo host) |

---

## 📝 Scripts disponíveis

```json
{
  "scripts": {
    "dev": "nodemon src/server.js",
    "start": "node src/server.js"
  }
}
```

- `npm run dev` - Desenvolvimento com auto-reload
- `npm start` - Produção

---

## 🔄 Fluxo de Dados

```
HTML (index.html)
    ↓ fetch POST/GET/PUT/DELETE
[Servidor Express]
    ↓
Routes (filaRoutes.js)
    ↓
Controllers (filaController.js) - Valida entrada
    ↓
Services (filaService.js) - Executa lógica
    ↓
Resposta JSON
    ↓
JavaScript (carregarDados) - Atualiza tabela
```

---

## 💡 Notas Importantes

- **Dados em memória**: Ao reiniciar servidor, fila limpa
- **Prioridade**: Pessoas com tipo "prioridade" são atendidas primeiro
- **Timestamps**: Formato brasileiro (DD/MM/YYYY, HH:mm:ss)
- **Edição**: Possível editar nome e tipo antes de atendimento
- **Status**: Card superior mostra totais atualizados em tempo real

---

## 📞 Suporte

Para dúvidas sobre a implementação, verifique:
- `src/server.js` - Como express inicia
- `src/services/filaservice.js` - Lógica de prioridade
- `src/views/index.html` - Funções de fetch
- `package.json` - Scripts e dependências

---

Última atualização: **08/06/2026**