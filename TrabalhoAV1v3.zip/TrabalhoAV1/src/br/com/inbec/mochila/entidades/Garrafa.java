package br.com.inbec.mochila.entidades;

public class Garrafa extends Objeto {
    public Garrafa(String nome, double peso, int id) {
        super(nome, peso, id);
    }

    public void abrir() {
        System.out.println(getNome() + " está aberta.");
    }

    public void fechar() {
        System.out.println(getNome() + " está fechada.");
    }

    @Override
    public void acao() {
        // Implementação da ação específica da Garrafa
    }
}