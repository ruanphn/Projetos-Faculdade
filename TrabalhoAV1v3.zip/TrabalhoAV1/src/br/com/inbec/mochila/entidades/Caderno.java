package br.com.inbec.mochila.entidades;

public class Caderno extends Objeto {
    public Caderno(String nome, double peso, int id) {
        super(nome, peso, id);
    }

    public void abrir() {
        System.out.println(getNome() + " está aberto.");
    }

    public void fechar() {
        System.out.println(getNome() + " está fechado.");
    }

    @Override
    public void acao() {
        // Implementação da ação específica do Caderno
    }
}
