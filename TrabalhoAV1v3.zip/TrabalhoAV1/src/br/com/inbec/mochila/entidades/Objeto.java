package br.com.inbec.mochila.entidades;

public abstract class Objeto {
    private String nome; // Nome do objeto
    private double peso; // Peso do objeto
    private int id; // ID do objeto

    // Construtor para inicializar o nome, peso e id do objeto
    public Objeto(String nome, double peso, int id) {
        this.nome = nome;
        this.peso = peso;
        this.id = id;
    }

    // Método para obter o nome do objeto
    public String getNome() {
        return nome;
    }

    // Método para obter o peso do objeto
    public double getPeso() {
        return peso;
    }

    // Método para obter o id do objeto
    public int getId() {
        return id;
    }

    // Método abstrato que será implementado pelas subclasses
    public abstract void acao();

    // Método para representar o objeto como uma string
    @Override
    public String toString() {
        return "ID: " + id + ", " + nome + " (" + peso + "kg)";
    }
}
