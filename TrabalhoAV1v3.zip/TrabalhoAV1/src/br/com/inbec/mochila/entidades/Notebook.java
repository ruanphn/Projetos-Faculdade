package br.com.inbec.mochila.entidades;

public class Notebook extends Objeto {
    public Notebook(String nome, double peso, int id) {
        super(nome, peso, id);
    }

    public void ligar() {
        System.out.println(getNome() + " está ligado.");
    }

    public void desligar() {
        System.out.println(getNome() + " está desligado.");
    }

    @Override
    public void acao() {
        // Implementação da ação específica do Notebook
    }
}
