package br.com.inbec.mochila;

import java.util.Scanner;
import br.com.inbec.banco.enums.OpcoesMenu;
import br.com.inbec.mochila.entidades.Caderno;
import br.com.inbec.mochila.entidades.Celular;
import br.com.inbec.mochila.entidades.Garrafa;
import br.com.inbec.mochila.entidades.Notebook;
import br.com.inbec.mochila.entidades.Objeto;

public class SistemaMochila {

	// Scanner para leitura de entrada do usuário
    private static Scanner scanner = new Scanner(System.in);
    
    // Instância da mochila com capacidade de 3.0 kg
    private static Mochila mochila = new Mochila(3.0);
    private static int idCounter = 1; // Contador para gerar IDs únicos

    public static void main(String[] args) {
        
    	String opcao = "";

    	   // Loop principal do sistema
    	while (!opcao.equalsIgnoreCase(OpcoesMenu.QUIT.getCodigo())) {
            imprimirOpcoes();
            opcao = scanner.next();

            // Verifica a opção escolhida pelo usuário
            if (opcao.equals(OpcoesMenu.LIST_OBJETO.getCodigo())) {
            	
                listarObjetos(); //lista de objetos na mochila
                
            } else if (opcao.equals(OpcoesMenu.ADD_OBJETO.getCodigo())) {
            	
                adicionarObjeto(); //adiciona objetos na mochila
                
            } else if (opcao.equals(OpcoesMenu.EXECUTE_ACAO.getCodigo())) {
                
            	executarAcao();
            } else if (opcao.equals(OpcoesMenu.DESCRICAO_OBJETOS.getCodigo())) {
               
            	exibirDescricaoObjetos();
            	
            } else if (opcao.equalsIgnoreCase(OpcoesMenu.QUIT.getCodigo())) {
                System.out.println("Saindo do sistema...");
                
            } else {
            	
                System.out.println("Opcao Invalida! " + opcao);
                
            }
            
        }

        System.out.println("Sistema Finalizado!");
    }

 // Método para imprimir as opções do menu
    private static void imprimirOpcoes() {
       
    	System.out.println("*********************************");
        System.out.println("Informe uma opcao:");

        for (OpcoesMenu opt : OpcoesMenu.values()) {
            System.out.println(opt.getCodigo() + " - " + opt.getDescricao());
        }

        System.out.println("*********************************");
    }

    // Método para listar os objetos na mochila
    private static void listarObjetos() {
        mochila.listarObjetos();
    }

 // Método para adicionar um objeto na mochila
    private static void adicionarObjeto() {
       
    	System.out.println("Você pode guardar os seguintes objetos: Notebook, Celular, Caderno ou Garrafa");
        System.out.println("Digite o nome do objeto a ser inserido:");
        
        String nomeObjeto = scanner.next();
        Objeto objeto = criarObjeto(nomeObjeto);
        
        if (objeto != null) {
        	
            mochila.adicionarObjeto(objeto);
            
        } else {
            System.out.println("Objeto inválido!");
        }
    }

 // Método para remover um objeto da mochila
    private static void removerObjeto() {
        System.out.println("Escolha o método de remoção:");
        System.out.println("1 - Por ID");
        System.out.println("2 - Por Peso");
        System.out.println("3 - Por Tamanho");

        int escolha = scanner.nextInt();

        if (escolha == 1) {
            System.out.println("Digite o ID do objeto a ser removido:");
            int id = scanner.nextInt();
            mochila.removerObjetoPorId(id);
        } else if (escolha == 2) {
            System.out.println("Digite o peso do objeto a ser removido:");
            System.out.println("1.5, 1.0, 0.7 ou 0.2");
            double peso = scanner.nextDouble();
            mochila.removerObjetoPorPeso(peso);
        } else if (escolha == 3) {
            System.out.println("Digite o tamanho do objeto a ser removido (pequeno, médio, grande):");
            String tamanho = scanner.next();
            mochila.removerObjetoPorTamanho(tamanho);
        } else {
            System.out.println("Opção inválida!");
        }
    }

    // método para executar ação de objeto armazenado
    private static void executarAcao() {
      
    	System.out.println("Digite o nome do objeto para executar a ação:");
        String nomeObjeto = scanner.next();
        
        if (mochila.contemObjeto(nomeObjeto)) {
        	
            System.out.println("Digite a ação a ser executada (ligar, desligar, abrir, fechar):");
            String acao = scanner.next();
            
            mochila.executarAcao(nomeObjeto, acao);
            
        } else {
        	
            System.out.println("Objeto não encontrado na mochila!");
        }
    }

    // método para criar um objeto
    private static Objeto criarObjeto(String nome) {
        nome = nome.toLowerCase();
        int id = idCounter++; // Gera um ID único para cada objeto

        if (nome.equals("notebook")) {
            return new Notebook(nome, 1.5, id);
        } else if (nome.equals("caderno")) {
            return new Caderno(nome, 0.5, id);
        } else if (nome.equals("celular")) {
            return new Celular(nome, 0.2, id);
        } else if (nome.equals("garrafa")) {
            return new Garrafa(nome, 0.7, id);
        } else {
            return null;
        }
    }


private static void exibirDescricaoObjetos() {
    String descricaoObjetos = "Objetos disponíveis:\n" +
        "1. Notebook - Peso: 1.5kg, Tamanho: Grande\n" +
        "2. Caderno - Peso: 0.5kg, Tamanho: Pequeno\n" +
        "3. Celular - Peso: 0.2kg, Tamanho: Pequeno\n" +
        "4. Garrafa - Peso: 0.7kg, Tamanho: Médio\n" +
        "5. Sobre tamanhos:\n" +
        "   - Pequeno: até 0.5kg\n" +
        "   - Médio: 0.5kg a 1.5kg\n" +
        "   - Grande: acima de 1.5kg";
    System.out.println(descricaoObjetos);
}
}