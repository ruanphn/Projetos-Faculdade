package br.com.inbec.mochila;

import java.util.HashMap;
import java.util.Map;

import br.com.inbec.mochila.entidades.Caderno;
import br.com.inbec.mochila.entidades.Celular;
import br.com.inbec.mochila.entidades.Garrafa;
import br.com.inbec.mochila.entidades.Notebook;
import br.com.inbec.mochila.entidades.Objeto;

public class Mochila {
    private Map<Integer, Objeto> objetos;
    private double pesoMaximo;
    private double pesoAtual;

    public Mochila(double pesoMaximo) {
        this.objetos = new HashMap<>();
        this.pesoMaximo = pesoMaximo;
        this.pesoAtual = 0;
    }

    public void adicionarObjeto(Objeto objeto) {
        if (pesoAtual + objeto.getPeso() <= pesoMaximo) {
            objetos.put(objeto.getId(), objeto);
            pesoAtual += objeto.getPeso();
            System.out.println(objeto.getNome() + " foi adicionado à mochila.");
        } else {
            System.out.println("Não é possível adicionar " + objeto.getNome() + ". Peso excedido!");
        }
    }

    public void removerObjetoPorId(int id) {
        Objeto objetoRemover = objetos.remove(id);
        if (objetoRemover != null) {
            pesoAtual -= objetoRemover.getPeso();
            System.out.println(objetoRemover.getNome() + " foi removido da mochila.");
        } else {
            System.out.println("Objeto com ID " + id + " não encontrado na mochila.");
        }
    }

    public void removerObjetoPorPeso(double peso) {
        for (Objeto objeto : objetos.values()) {
            if (objeto.getPeso() == peso) {
                objetos.remove(objeto.getId());
                pesoAtual -= objeto.getPeso();
                System.out.println(objeto.getNome() + " foi removido da mochila.");
                break;
            }
        }
    }

    public void removerObjetoPorTamanho(String tamanho) {
        Objeto objetoRemover = null;
        for (Objeto objeto : objetos.values()) {
            if (tamanho.equalsIgnoreCase("pequeno") && objeto.getPeso() <= 0.5) {
                objetoRemover = objeto;
                break;
            } else if (tamanho.equalsIgnoreCase("médio") && objeto.getPeso() > 0.5 && objeto.getPeso() <= 1.5) {
                objetoRemover = objeto;
                break;
            } else if (tamanho.equalsIgnoreCase("grande") && objeto.getPeso() > 1.5) {
                objetoRemover = objeto;
                break;
            }
        }
        if (objetoRemover != null) {
            objetos.remove(objetoRemover.getId());
            pesoAtual -= objetoRemover.getPeso();
            System.out.println(objetoRemover.getNome() + " foi removido da mochila.");
        } else {
            System.out.println("Nenhum objeto de tamanho " + tamanho + " encontrado na mochila.");
        }
    }

    public void listarObjetos() {
        System.out.println("Objetos na mochila:");
        if (objetos.isEmpty()) {
            System.out.println("A mochila está vazia.");
        } else {
            for (Objeto objeto : objetos.values()) {
                System.out.println("- " + objeto);
            }
        }
        System.out.println("Peso total: " + pesoAtual + "kg");
    }

    public void executarAcao(String nome, String acao) {
        for (Objeto objeto : objetos.values()) {
            if (objeto.getNome().equalsIgnoreCase(nome)) {
                acao = acao.toLowerCase();
                if (acao.equals("ligar")) {
                    if (objeto instanceof Notebook) {
                        ((Notebook) objeto).ligar();
                    } else if (objeto instanceof Celular) {
                        ((Celular) objeto).ligar();
                    } else {
                        System.out.println("Ação inválida para " + objeto.getNome());
                    }
                } else if (acao.equals("desligar")) {
                    if (objeto instanceof Notebook) {
                        ((Notebook) objeto).desligar();
                    } else if (objeto instanceof Celular) {
                        ((Celular) objeto).desligar();
                    } else {
                        System.out.println("Ação inválida para " + objeto.getNome());
                    }
                } else if (acao.equals("abrir")) {
                    if (objeto instanceof Caderno) {
                        ((Caderno) objeto).abrir();
                    } else if (objeto instanceof Garrafa) {
                        ((Garrafa) objeto).abrir();
                    } else {
                        System.out.println("Ação inválida para " + objeto.getNome());
                    }
                } else if (acao.equals("fechar")) {
                    if (objeto instanceof Caderno) {
                        ((Caderno) objeto).fechar();
                    } else if (objeto instanceof Garrafa) {
                        ((Garrafa) objeto).fechar();
                    } else {
                        System.out.println("Ação inválida para " + objeto.getNome());
                    }
                } else {
                    System.out.println("Ação inválida!");
                }
                return;
            }
        }
        System.out.println(nome + " não encontrado na mochila.");
    }

    public boolean contemObjeto(String nome) {
        for (Objeto objeto : objetos.values()) {
            if (objeto.getNome().equalsIgnoreCase(nome)) {
                return true;
            }
        }
        return false;
    }
}
