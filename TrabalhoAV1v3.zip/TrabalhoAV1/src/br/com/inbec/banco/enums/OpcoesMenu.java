package br.com.inbec.banco.enums;

public enum OpcoesMenu {
	
	LIST_OBJETO("1", "Listar Objetos Armazenados"),
	ADD_OBJETO( "2",  "Adicionar Objeto"), 
	REMOVE_OBJETO( "3", "Remover Objeto"),
	EXECUTE_ACAO("4", "Executar Ação"),
	DESCRICAO_OBJETOS("5", "Descrição dos Objetos"),
	QUIT("x", "Fechar Mochila");
		
	private String codigo;
	private String descricao;
	
	private OpcoesMenu( String codigo, String descricao ){
		
		this.codigo = codigo;
		this.descricao = descricao;				
	}
		
	public String getCodigo() {
		
		return codigo;		
	}
	
	public String getDescricao() {
		
		return descricao;
		
	}


}


