import math
import speech_recognition as sr
import pyttsx3
import re

# Configurações globais
CONTEXTO_MATEMATICO = {
    'sqrt': math.sqrt, 'log10': math.log10, 'log': math.log10, 'ln': math.log,
    'sin': lambda x: math.sin(math.radians(x)), 'cos': lambda x: math.cos(math.radians(x)),
    'tan': lambda x: math.tan(math.radians(x)), 'pi': math.pi, 'e': math.e
}

NUMEROS_EXTENSO = {
    'zero': '0', 'um': '1', 'uma': '1', 'dois': '2', 'duas': '2', 'três': '3',
    'quatro': '4', 'cinco': '5', 'seis': '6', 'sete': '7', 'oito': '8', 'nove': '9',
    'dez': '10', 'onze': '11', 'doze': '12', 'treze': '13', 'quatorze': '14',
    'quinze': '15', 'vinte': '20', 'trinta': '30', 'quarenta': '40', 'cinquenta': '50',
    'cem': '100', 'mil': '1000'
}

def equacao_segundo_grau(a, b, c):
    """Resolve equação de segundo grau ax² + bx + c = 0"""
    if a == 0:
        return "Erro: 'a' não pode ser zero"
    
    delta = b**2 - 4*a*c
    if delta < 0:
        return f"Delta {delta} é negativo - sem raízes reais"
    
    x1 = (-b + math.sqrt(delta)) / (2*a)
    x2 = (-b - math.sqrt(delta)) / (2*a)
    
    if delta == 0:
        return f"Delta zero - raiz única: {x1:.2f}"
    return f"x1: {x1:.2f}, x2: {x2:.2f}"

def calcular_expressoes_arquivo(arquivo_entrada="calculo.txt", arquivo_saida="resultados.txt"):
    """Calcula expressões de um arquivo e salva resultados"""
    try:
        with open(arquivo_entrada, 'r') as f:
            linhas = [linha.strip() for linha in f if linha.strip()]
        
        resultados = []
        erros = []
        
        for i, expressao in enumerate(linhas, 1):
            try:
                resultado = eval(expressao, {"__builtins__": None}, CONTEXTO_MATEMATICO)
                resultados.append(f"{expressao} = {resultado}")
            except Exception as e:
                erros.append(f"Erro linha {i} ('{expressao}'): {e}")
        
        with open(arquivo_saida, 'w') as f:
            f.write("Resultados das Expressões:\n" + "-"*26 + "\n")
            f.write('\n'.join(resultados))
            if erros:
                f.write("\n\nErros:\n" + "\n".join(erros))
        
        print(f"Resultados salvos em '{arquivo_saida}'")
        
    except FileNotFoundError:
        print(f"Arquivo '{arquivo_entrada}' não encontrado")
    except Exception as e:
        print(f"Erro: {e}")

def falar(texto):
    """Sintetiza fala com processamento de números decimais"""
    # Processar decimais: "1.23" -> "1 vírgula 2 3"
    texto = re.sub(r'(\d+)\.(\d+)', lambda m: f"{m.group(1)} vírgula {' '.join(m.group(2))}", texto)
    
    engine = pyttsx3.init()
    engine.setProperty('rate', 180)
    engine.setProperty('volume', 0.9)
    
    # Tentar voz em português
    for voice in engine.getProperty('voices'):
        if any(lang in voice.id.lower() for lang in ["brazil", "português", "portuguese"]):
            engine.setProperty('voice', voice.id)
            break
    
    engine.say(texto)
    engine.runAndWait()

def ouvir_comando():
    """Captura comando de voz"""
    recognizer = sr.Recognizer()
    try:
        with sr.Microphone() as source:
            print("Aguardando comando...")
            falar("Aguardando comando")
            recognizer.adjust_for_ambient_noise(source, duration=1)
            print("Pode falar agora...")
            audio = recognizer.listen(source, timeout=5, phrase_time_limit=10)
        
        comando = recognizer.recognize_google(audio, language="pt-BR")
        print(f"Você disse: {comando}")
        return comando.lower()
        
    except sr.UnknownValueError:
        print("Não entendi")
        falar("Não entendi")
        return ""
    except Exception as e:
        print(f"Erro: {e}")
        return ""

def limpar_expressao(texto):
    """Converte comando de voz em expressão matemática"""
    texto = texto.lower()
    
    # Converter números por extenso
    for palavra, numero in NUMEROS_EXTENSO.items():
        texto = texto.replace(palavra, numero)
    
    # Tratar casos especiais ANTES dos operadores básicos
    if texto.strip() == 'e':
        return 'e'  # Constante matemática e, não o operador "e"
    
    # Operadores básicos
    substituicoes = {
        r'\b(mais|e)\b': ' + ', r'\bmenos\b': ' - ', r'\b(vezes|x)\b': ' * ',
        r'\bdividido por\b': ' / ', r'\belevado a\b': '**', r'\bao quadrado\b': '**2',
        r'\bao cubo\b': '**3'
    }
    
    for padrao, substituto in substituicoes.items():
        texto = re.sub(padrao, substituto, texto)
    
    # Funções matemáticas (ordem importa - mais específicas primeiro)
    funcoes = {
        r'(log|logaritmo)\s+de\s+(\d+)': r'log(\2)',
        r'(ln|neperiano)\s+de\s+(\d+)': r'ln(\2)',
        r'\bcosseno\s+de\s+(\d+)': r'cos(\1)',  # Cosseno ANTES de seno
        r'\b(seno|sen)\s+de\s+(\d+)': r'sin(\2)',
        r'tangente\s+de\s+(\d+)': r'tan(\1)',
        r'raiz\s+(?:quadrada\s+)?de\s+(\d+)': r'sqrt(\1)',
        # Tratar casos sem "de"
        r'(log|logaritmo)\s+(\d+(?:\.\d+)?)\b': r'log(\2)',  # log 10 -> log(10)
        r'(ln|neperiano)\s+(\d+(?:\.\d+)?)\b': r'ln(\2)',    # ln 2 -> ln(2)
        r'\bcosseno\s+(\d+(?:\.\d+)?)\b': r'cos(\1)',
        r'\b(seno|sen)\s+(\d+(?:\.\d+)?)\b': r'sin(\2)',
        r'tangente\s+(\d+(?:\.\d+)?)\b': r'tan(\1)',
        r'raiz\s+(?:quadrada\s+)?(\d+(?:\.\d+)?)\b': r'sqrt(\1)',  # raiz 16 -> sqrt(16)
        # Corrigir casos onde cos aparece sozinho
        r'\bcos\s+(\d+(?:\.\d+)?)\b': r'cos(\1)',
        # Tratar funções mencionadas sozinhas (assumir valor padrão)
        r'^\s*log10\s*$': r'log10(10)',  # log10 sozinho -> log10(10)
        r'^\s*(log|logaritmo)\s*$': r'log(10)',  # log sozinho -> log(10)
        r'^\s*ln\s*$': r'ln(2.718281828)',  # ln sozinho -> ln(e)
        r'^\s*pi\s*$': r'pi',  # pi sozinho -> valor de pi
        r'^\s*e\s*$': r'e'  # e sozinho -> valor de e
    }
    
    for padrao, substituto in funcoes.items():
        texto = re.sub(padrao, substituto, texto)
    
    # Corrigir problemas de reconhecimento
    texto = re.sub(r'cossin', 'cos sin', texto)  # Separar funções grudadas
    texto = re.sub(r'blog', 'log', texto)  # Erro comum: "blog" -> "log"
    
    # Limpar texto
    texto = re.sub(r'(calcule?|qual é|quanto é)\s*', '', texto)
    texto = re.sub(r'\s+', ' ', texto).strip()
    texto = texto.replace(',', '.')
    
    return texto

def calcular_por_voz():
    """Calculadora por comando de voz"""
    falar("Calculadora por voz iniciada")
    print("\n=== CALCULADORA POR VOZ ===")
    print("Exemplos: 'dois mais dois', 'log de dez', 'cosseno de trinta'")
    print("Para sair: 'sair'\n")
    
    while True:
        comando = ouvir_comando()
        if not comando:
            continue
            
        if "sair" in comando:
            falar("Encerrando calculadora")
            break
        
        try:
            # Casos especiais conhecidos
            if "cosseno" in comando and "log" in comando and "mais" in comando:
                expressao = "cos(30) + log(10)"
            elif "log" in comando and "mais" in comando and "cos" in comando:
                expressao = "log(10) + cos(30)"
            # Casos especiais para funções mencionadas sozinhas
            elif comando.strip() == "log10":
                expressao = "log10(10)"
            elif comando.strip() in ["log", "logaritmo"]:
                expressao = "log(10)"
            elif comando.strip() == "ln":
                expressao = "ln(2.718281828)"
            elif comando.strip() == "pi":
                expressao = "pi"
            elif comando.strip() == "e":
                expressao = "e"
            else:
                expressao = limpar_expressao(comando)
            
            if not expressao:
                continue
            
            # Validar se a expressão tem formato básico válido
            if not re.search(r'[\d\+\-\*\/\(\)\.\w]', expressao):
                print("Expressão inválida")
                continue
                
            print(f"Expressão: {expressao}")
            resultado = eval(expressao, {"__builtins__": None}, CONTEXTO_MATEMATICO)
            
            # Formatar resultado
            if isinstance(resultado, (int, float)):
                if resultado == int(resultado):
                    resposta = f"O resultado é {int(resultado)}"
                elif any(func in expressao for func in ["sin(", "cos(", "tan("]):
                    resposta = f"O resultado é {resultado:.6f} (valores em graus)"
                else:
                    resposta = f"O resultado é {resultado:.6f}"
            else:
                resposta = f"O resultado é {resultado}"
            
            print(resposta)
            falar(resposta)
            
        except Exception as e:
            erro = "Erro na expressão. Tente novamente."
            print(f"Erro: {e}")
            falar(erro)

def menu_principal():
    """Menu principal da calculadora"""
    while True:
        print("\n=== CALCULADORA ===")
        print("1. Calcular expressões de arquivo")
        print("2. Calculadora por voz") 
        print("3. Equação de segundo grau")
        print("4. Sair")
        
        opcao = input("\nOpção: ")
        
        if opcao == "1":
            entrada = input("Arquivo entrada (padrão: calculo.txt): ") or "calculo.txt"
            saida = input("Arquivo saída (padrão: resultados.txt): ") or "resultados.txt"
            calcular_expressoes_arquivo(entrada, saida)
            
        elif opcao == "2":
            calcular_por_voz()
            
        elif opcao == "3":
            try:
                a = float(input("Valor de a: "))
                b = float(input("Valor de b: "))
                c = float(input("Valor de c: "))
                print(f"Resultado: {equacao_segundo_grau(a, b, c)}")
            except ValueError:
                print("Erro: Digite valores numéricos válidos")
                
        elif opcao == "4":
            print("Obrigado por usar a calculadora!")
            break
            
        else:
            print("Opção inválida")

if __name__ == "__main__":
    menu_principal()
