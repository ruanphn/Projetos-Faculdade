const express = require('express');
const filaRoutes = require('./routes/filaRoutes');
const app = express();

app.use(express.json());
app.use('/fila', filaRoutes);

app.get('/', (req, res) => {
	res.send('API funcionando!');
});

const port = process.env.PORT || 3000;
app.listen(port, () => {
	console.log(`Servidor rodando na porta ${port}`);
});

module.exports = app;
