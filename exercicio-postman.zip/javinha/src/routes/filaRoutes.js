const express = require('express');
const filaController = require('../controllers/filacontroller');
const router = express.Router();

router.post('/', filaController.adicionarPessoa);
router.get('/', filaController.listarFila);
router.post('/chamar', filaController.chamarProximo);
router.get('/atendidos', filaController.listarAtendidos);
router.delete('/:id', filaController.removerPessoa);
router.get('/status', filaController.statusFila);

module.exports = router;
