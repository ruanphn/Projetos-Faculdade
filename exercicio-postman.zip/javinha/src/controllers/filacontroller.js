const filaService = require('../services/filaservice');

function adicionarPessoa(req, res) {
  const { nome, tipo } = req.body;
  if (!nome) {
    return res.status(400).json({ mensagem: 'Nome obrigatório' });
  }
  const pessoa = filaService.adicionarPessoa(nome, tipo);
  return res.status(201).json(pessoa);
}

function listarFila(req, res) {
  return res.json(filaService.listarFila());
}

function chamarProximo(req, res) {
  const pessoa = filaService.chamarProximo();
  if (!pessoa) {
    return res.status(404).json({ mensagem: 'Fila vazia' });
  }
  return res.json(pessoa);
}

function listarAtendidos(req, res) {
  return res.json(filaService.listarAtendidos());
}

function removerPessoa(req, res) {
  const pessoa = filaService.removerPessoa(req.params.id);
  if (!pessoa) {
    return res.status(404).json({ mensagem: 'Pessoa não encontrada' });
  }
  return res.json(pessoa);
}

function statusFila(req, res) {
  return res.json(filaService.statusFila());
}

module.exports = {
  adicionarPessoa,
  listarFila,
  chamarProximo,
  listarAtendidos,
  removerPessoa,
  statusFila
};
