let fila = [];
let atendidos = [];
let idAtual = 1;

function adicionarPessoa(nome, tipo) {
  const pessoa = {
    id: idAtual++,
    nome,
    tipo: tipo || 'normal',
    status: 'aguardando'
  };
  fila.push(pessoa);
  return pessoa;
}

function listarFila() {
  return fila;
}

function chamarProximo() {
  if (fila.length === 0) return null;
  const indicePrioridade = fila.findIndex(p => p.tipo === 'prioridade');
  let pessoa;
  if (indicePrioridade !== -1) {
    pessoa = fila.splice(indicePrioridade, 1)[0];
  } else {
    pessoa = fila.shift();
  }
  pessoa.status = 'atendido';
  atendidos.push(pessoa);
  return pessoa;
}

function listarAtendidos() {
  return atendidos;
}

function removerPessoa(id) {
  const index = fila.findIndex(p => p.id === Number(id));
  if (index === -1) return null;
  return fila.splice(index, 1)[0];
}

function statusFila() {
  return {
    aguardando: fila.length,
    atendidos: atendidos.length
  };
}

module.exports = {
  adicionarPessoa,
  listarFila,
  chamarProximo,
  listarAtendidos,
  removerPessoa,
  statusFila
};
