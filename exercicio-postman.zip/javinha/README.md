# API Fila de Atendimento

Projeto simples de API para gerenciar uma fila de atendimento (exercício).

## Pré-requisitos
- Node.js (v16+ recomendado)

## Instalação
1. No diretório do projeto, instale dependências:

```bash
npm install
```

2. Rodar em desenvolvimento (com `nodemon`):

```bash
npm run dev
```

3. Rodar em produção:

```bash
npm start
```

O servidor roda por padrão na porta `3000`.

## Scripts úteis (em `package.json`)
- `dev`: inicia com `nodemon` (observa mudanças)
- `start`: inicia com `node` (produção)

## Endpoints
Base URL: `http://localhost:3000`

- POST `/fila` — adiciona uma pessoa na fila
  - Body JSON: `{ "nome": "Maria", "tipo": "normal" }`
  - `tipo` pode ser `normal` ou `prioridade` (opcional)

- GET `/fila` — lista pessoas aguardando

- POST `/fila/chamar` — chama o próximo da fila (prioridade primeiro)

- GET `/fila/atendidos` — lista de pessoas já atendidas

- GET `/fila/status` — retorna `{ aguardando: N, atendidos: M }`

- DELETE `/fila/:id` — remove pessoa da fila pelo `id`

## Exemplos com `curl`

Adicionar:
```bash
curl -X POST http://localhost:3000/fila \
  -H "Content-Type: application/json" \
  -d '{"nome":"João","tipo":"prioridade"}'
```

Chamar próximo:
```bash
curl -X POST http://localhost:3000/fila/chamar
```

Listar fila:
```bash
curl http://localhost:3000/fila
```

Status:
```bash
curl http://localhost:3000/fila/status
```

Remover pelo id (ex: 1):
```bash
curl -X DELETE http://localhost:3000/fila/1
```

## Testes
Você pode usar o Postman ou Insomnia para testar os endpoints acima. Use o JSON indicado nos exemplos.

## Observações
- A implementação atual usa memória local (arrays). Ao reiniciar o servidor os dados são perdidos.
- Se quiser, posso acrescentar persistência (arquivo JSON ou banco de dados leve).